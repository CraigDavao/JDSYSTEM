<?php
$host = "srv1319.hstgr.io"; // or Hostinger host
$user = "u251504662_group6";
$pass = "o7JOhio|T7";
$db = "u251504662_jollydolly";
$port = 3306;

$conn = new mysqli($host, $user, $pass, $db, $port);

if ($conn->connect_error) {
    die("❌ Database connection failed: " . $conn->connect_error);
} else {
    echo "✅ Database connected successfully!";
}
?>
