<?php
// define("SITE_URL", "http://localhost/JDSystem/");
// define("DB_HOST", "localhost");
// define("DB_USER", "root");
// define("DB_PASS", "");
// define("DB_NAME", "jolly_database");

// define("SITE_URL", getenv('SITE_URL') ?: '/');

define("SITE_URL", "https://jollydolly.shop/");
define("DB_HOST", "srv1319.hstgr.io");
define("DB_USER", "u251504662_group6");
define("DB_PASS", "o7JOhio|T7");
define("DB_NAME", "u251504662_jollydolly");
define("DB_PORT", 3306);
?>