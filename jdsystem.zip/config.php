<?php
define("SITE_URL", "http://localhost/JDSystem/");
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "jolly_database");

// define("SITE_URL", getenv('SITE_URL') ?: '/');
// define("DB_HOST", "b3sl32ekxzydrb5wscjh-mysql.services.clever-cloud.com");
// define("DB_USER", "ujowc00747fduqvq");
// define("DB_PASS", "mDScdVXVx0pc74ibViLe");
// define("DB_NAME", "b3sl32ekxzydrb5wscjh");
?>
